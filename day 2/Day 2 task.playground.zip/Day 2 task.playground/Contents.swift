//: Playground - noun: a place where people can play

import UIKit

var firstName = String()
firstName = "Charles"
var length = firstName.count
print(length)

for i in stride(from: 0, to: length, by: 1){
    let count = i
    print(firstName[firstName.index(firstName.startIndex,offsetBy: count)])
}

for i in stride (from: length,to: 0, by: -1)
{
    let count = i-length-1
    
    print(firstName[firstName.index(firstName.endIndex,offsetBy: count)])
}
print("\n")
print(length)
