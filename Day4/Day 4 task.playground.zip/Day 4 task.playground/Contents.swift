//: Playground - noun: a place where people can play

import UIKit


struct address {
    var street = "271 BouLevard"
 var city = "Toronto"
var postalCode = "M1H1W2"
}

class Persons {
    var Firstname = "Charles"
 var Lastname = "Jaison"
    var age = 20
   var Total_amount = 2000
    var location = address()
    
}

var person_details = Persons()
print("First Name :" , person_details.Firstname)
print("Last name:",person_details.Lastname)
print("Age:",person_details.age)
print("Street:",person_details.location.street)
print("City:",person_details.location.city)
print("postalCode:",person_details.location.postalCode)
